<body>

	<!-- Start Header Area -->
	<header class="header_area sticky-header">
		<div class="main_menu">
